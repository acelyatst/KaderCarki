#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

// Oyuncu bilgileri
struct Oyuncu {
    char isim[30];
    int yas;
    int saglik;
    int mutluluk;
    int zeka;
    int gorunus;
    int para;
    int rastgeleOlay1;
    int rastgeleOlay2;
 };

#define MAX_OLAY_1 8
#define MAX_OLAY_2 8

int olayDurum1[MAX_OLAY_1] = {0};
int olayDurum2[MAX_OLAY_2] = {0};

// Fonksiyon Prototipleri
void rastgeleOlay1(struct Oyuncu *oyuncu); // 3-9 yaş
void rastgeleOlay2(struct Oyuncu *oyuncu); // 10-20 yaş
void oyuncuBilgileriYazdir(struct Oyuncu *oyuncu);
int oyunBittiMi(struct Oyuncu *oyuncu);
int yasbitti(struct Oyuncu *oyuncu);
void degerGuncelle(int *deger, int degisim, int min, int max); 
void temizleEkran();

void degerGuncelle(int *deger, int degisim, int min, int max) {
    *deger += degisim;
    if (*deger > max) *deger = max;
    if (*deger < min) *deger = min;
}

void temizleEkran() {
    #ifdef _WIN32
        system("cls"); // Windows için
    #else
        system("clear"); // Linux/Mac için
    #endif
}

void oyuncuBilgileriYazdir(struct Oyuncu *oyuncu) {
    temizleEkran();
    printf("\n--- Oyuncu Bilgileri ---\n");
    printf("Isim: %s\n", oyuncu->isim);
    printf("Yas: %d\n", oyuncu->yas);
    printf("Saglik: %d\n", oyuncu->saglik);
    printf("Mutluluk: %d\n", oyuncu->mutluluk);
    printf("Zeka: %d\n", oyuncu->zeka);
    printf("Gorunus: %d\n", oyuncu->gorunus);
    printf("Para: %d\n", oyuncu->para);
    printf("- - - - - - - - - - - - - -\n");
}

void rastgeleOlay1(struct Oyuncu *oyuncu) {
    int olay = rand() % MAX_OLAY_1;

    while (olayDurum1[olay] == 1) {
        olay = rand() % MAX_OLAY_1;
    }

    olayDurum1[olay] = 1;

    int secim;
    switch (olay) {
        case 0:
            printf("\nAnneniz sizi hastaneye asi olmaya goturdu. Ne yapacaksiniz?\n");
            printf("1. Agla (+10 Mutluluk, -5 Zeka)\n");
            printf("2. Uslu dur (+5 Para , -10 Mutluluk )\n");
            while (1) {
                printf("\nSeciminizi yapin (1/2): ");
                if (scanf("%d", &secim) == 1 && (secim == 1 || secim == 2)) {
                    if (secim == 1) {
                        degerGuncelle(&oyuncu->mutluluk, 10, 0, 100);
                        degerGuncelle(&oyuncu->zeka, -5, 0, 100);
                        printf("Aglak bebek oldugunuz icin agladiniz. Mutlulugunuz artti ancak zekaniz azaldi.\n");
                    } else {
                        degerGuncelle(&oyuncu->para, 5, 0, 100);
                        degerGuncelle(&oyuncu->mutluluk, -10, 0, 100);
                        printf("Uslu durdunuz. Anneniz size para verdi ama aglayamamak sizi mutsuz etti.\n");
                    }
                    break;
                } else {
                    printf("Gecersiz secim yaptiniz. Tekrar deneyin.\n");
                    while (getchar() != '\n');
                }
            }
            break;

        case 1:
            printf("\nBabanız sizi alisverise goturmek istiyor. Ne yapacaksiniz? \n");
            printf("1. Git (+10 Gorunus, -15 Zeka)\n");
            printf("2. Gitme (+10 Zeka, -18 Gorunus)\n");
            while (1) {
                printf("\nSeciminizi yapin (1/2): ");
                if (scanf("%d", &secim) == 1 && (secim == 1 || secim == 2)) {
                    if (secim == 1) {
                        degerGuncelle(&oyuncu->gorunus, 10, 0, 100);
                        degerGuncelle(&oyuncu->zeka, -15, 0, 100);
                        printf("Alisverise gittiniz! Gorunusunuz artti, zekaniz azaldi.\n");
                    } else {
                        degerGuncelle(&oyuncu->zeka, 10, 0, 100);
                        degerGuncelle(&oyuncu->gorunus, -18, 0, 100);
                        printf("Gitmemeyi sectiniz. Zekaniz artti ancak gorunusunuz azaldi.\n");
                    }
                    break;
                } else {
                    printf("Gecersiz secim yaptiniz. Tekrar deneyin.\n");
                    while (getchar() != '\n');
                }
            }
            break;

        case 2:
        printf("\nSokakta oyun oynarken tanimadiginiz bir cocuk size laf atti. Karsilik verecek misiniz? \n");
        printf("1. Karsilik ver. (+8 Mutluluk, -15 Gorunus)\n");
        printf("2. Duymamazliktan gel. (+7 Saglik, -16 Zeka)\n");
        while (1) {
            printf("\nSeciminizi yapin (1/2): ");
            if (scanf("%d", &secim) == 1 && (secim == 1 || secim == 2)) {
                if (secim == 1) {
                    degerGuncelle(&oyuncu->gorunus, -18, 0, 100);
                    degerGuncelle(&oyuncu->mutluluk, +8, 0, 100);
                    printf("Karsilik verdiniz fakat cocuk cok sinirlendi ve sana yumruk attı! Burnunuz kanadi.\n");
                } else {
                    degerGuncelle(&oyuncu->zeka, -16, 0, 100);
                    degerGuncelle(&oyuncu->saglik, 7, 0, 100);
                    printf("Duymamazliktan geldigin icin sana sagir dedi fakat dayak yemekten kurtuldun.\n");
                }
                break;
            } else {
                printf("Gecersiz secim yaptiniz. Tekrar deneyin.\n");
                while (getchar() != '\n');
            }
        }
        break;
        case 3:
        printf("\nAilecek disari ciktiniz ve size istediginiz atistirmaligi alabileceginizi soylediler. Ne alacaksiniz? \n");
        printf("1. Dondurma. (+8 Saglik, -7 Zeka)\n");
        printf("2. Cikolata. (+7 Gorunus, -9 Saglik)\n");
        printf("3. Parasini istiyorum. (+20 Para, -15 Mutluluk");
        while (1) {
            printf("\nSeciminizi yapin (1/2/3): ");
            if (scanf("%d", &secim) == 1 && (secim == 1 || secim == 2) || secim == 3) {
                if (secim == 1) {
                    degerGuncelle(&oyuncu->saglik, 8, 0, 100);
                    degerGuncelle(&oyuncu->zeka, -7, 0, 100);
                    printf("Dondurmani mutlu mutlu yedin ama soguktan basina agri girdi.\n");
                } else if (secim == 2) {
                    degerGuncelle(&oyuncu->saglik, -9, 0, 100);
                    degerGuncelle(&oyuncu->gorunus, 7, 0, 100);
                    printf("Cikolata yedigini goren diger cocuklar da cikolata istedi fakat disleriniz agrimaya basladi.\n");
                }
                else {
                    degerGuncelle(&oyuncu->mutluluk, -15, 0, 100);
                    degerGuncelle(&oyuncu->para, 20, 0, 100);
                    printf("Parasini istediginiz icin parasini aldiniz. Paraniz artti ama baska cocuklari gordugunuz icin uzuldunuz.\n");
                }
                break;

            } else {
                printf("Gecersiz secim yaptiniz. Tekrar deneyin.\n");
                while (getchar() != '\n');
            }
        }
        break;
        case 4:
        printf("\nTelevizyon izlemek istediniz ama anneniz su aralar cok izlediginizi soyleyip size izin vermedi. Ne yapacaksiniz?\n");
        printf("1. Izlememeyi kabul et. (+12 Zeka, -17 Mutluluk)\n");
        printf("2. Isyan et. (+11 Mutluluk, -14 Zeka )\n");
        while (1) {
            printf("\nSeciminizi yapin (1/2): ");
            if (scanf("%d", &secim) == 1 && (secim == 1 || secim == 2) || secim == 3) {
                if (secim == 1) {
                    degerGuncelle(&oyuncu->mutluluk, -17, 0, 100);
                    degerGuncelle(&oyuncu->zeka, 12, 0, 100);
                    printf("Annen senin uslu uslu onu dinledigini gorunce cok mutlu oldu.\n");
                } else {
                    degerGuncelle(&oyuncu->mutluluk, 11, 0, 100);
                    degerGuncelle(&oyuncu->zeka, -14, 0, 100);
                    printf("Isyan ettin ve annen sana kizdi.Araniz bozuldu.\n");
                }
                break;

            } else {
                printf("Gecersiz secim yaptiniz. Tekrar deneyin.\n");
                while (getchar() != '\n');
            }
        }
        break;
        case 5:
        printf("\nOkulunuzda bir tiyatro gosterisi olacak.Hangi rolu almak istersiniz? \n");
        printf("1. Basrolu oyna. (+14 Gorunus , -12 Mutluluk)\n");
        printf("2. Arka planda kal. (+12 Mutluluk, -14 Gorunus)\n");
        while (1) {
            printf("\nSeciminizi yapin (1/2): ");
            if (scanf("%d", &secim) == 1 && (secim == 1 || secim == 2) || secim == 3) {
                if (secim == 1) {
                    degerGuncelle(&oyuncu->gorunus, 14, 0, 100);
                    degerGuncelle(&oyuncu->mutluluk, -12, 0, 100);
                    printf("Basrol olmak istedin ve ogretmenin kabul etti! Arkadaslarin sana saygi duyuyor! Yogun programdan dolayi yoruldun.\n");
                } else {
                    degerGuncelle(&oyuncu->mutluluk, 12, 0, 100);
                    degerGuncelle(&oyuncu->gorunus, -14, 0, 100);
                    printf("Yogun program istemedin ve yardimci karakter oldun.Arkadaslarin basrol oyuncu olan kisiyle daha fazla ilgilenmeye basladi.\n");
                }
                break;

            } else {
                printf("Gecersiz secim yaptiniz. Tekrar deneyin.\n");
                while (getchar() != '\n');
            }
        }
        break;
        case 6:
        printf("\nAilenle dogum gununu kutlayacaksiniz! Size istediginiz oyuncagi alabileceginizi soylediler. Ne alacaksiniz? \n");
        printf("1. Lego. (+8 Zeka, -7 Gorunus)\n");
        printf("2. Tablet. (+7 Gorunus, -9 Saglik)\n");
        printf("3. Parasini istiyorum. (+100 Para, -15 Mutluluk");
        while (1) {
            printf("\nSeciminizi yapin (1/2/3): ");
            if (scanf("%d", &secim) == 1 && (secim == 1 || secim == 2) || secim == 3) {
                if (secim == 1) {
                    degerGuncelle(&oyuncu->gorunus, -7, 0, 100);
                    degerGuncelle(&oyuncu->zeka, +8, 0, 100);
                    printf("Legonla mutlu mutlu oynadin ama arkadaslarin senin garip biri oldugunu soyledi.\n");
                } else if (secim == 2) {
                    degerGuncelle(&oyuncu->saglik, -9, 0, 100);
                    degerGuncelle(&oyuncu->gorunus, 7, 0, 100);
                    printf("Tabletinizin oldugunu goren diger cocuklar da tablet istedi fakat gozleriniz agrimaya basladi.\n");
                }
                else {
                    degerGuncelle(&oyuncu->mutluluk, -15, 0, 100);
                    degerGuncelle(&oyuncu->para, 100, 0, 1000);
                    printf("Parasini istediginiz icin parasini aldiniz. Paraniz artti ama baska cocuklari gordugunuz icin uzuldunuz.\n");
                }
                break;

            } else {
                printf("Gecersiz secim yaptiniz. Tekrar deneyin.\n");
                while (getchar() != '\n');
            }
        }
        break;
        default:
            printf("Bu yilda bir olay yasanmadi.\n");
            break;
    }
}

void rastgeleOlay2(struct Oyuncu *oyuncu) {
    int olay = rand() % MAX_OLAY_2;

    while (olayDurum2[olay] == 1) {
        olay = rand() % MAX_OLAY_2;
    }

    olayDurum2[olay] = 1;

    int secim;
    switch (olay) {
        case 0:
            printf("\nOkulda spor etkinligi oluyor katilacak misin?\n");
            printf("1. Katil (+10 Gorunus, -5 Mutluluk)\n");
            printf("2. Katilma (+10 Mutluluk, -5 Gorunus)\n");
            while (1) {
                printf("Seciminizi yapin (1/2): ");
                if (scanf("%d", &secim) == 1 && (secim == 1 || secim == 2)) {
                    if (secim == 1) {
                        degerGuncelle(&oyuncu->gorunus, 10, 0, 100);
                        degerGuncelle(&oyuncu->mutluluk, -5, 0, 100);
                        printf("Etkinlige katildiniz! Okuldaki insanlar artik sizin farkinizda fakat mutlulugunuz azaldi.\n");
                    } else {
                        degerGuncelle(&oyuncu->gorunus, -5, 0, 100);
                        degerGuncelle(&oyuncu->mutluluk, 10, 0, 100);
                        printf("Katilmamayi sectiniz. Mutlulukla uzaktan izlediniz.\n");
                    }
                    break;
                } else {
                    printf("Gecersiz secim yaptiniz. Tekrar deneyin.\n");
                    while (getchar() != '\n');
                }
            } case 1:
            printf("\nAnneniz ve babaniz kavga ediyor. Ne yapacaksiniz ?\n");
            printf("1. Konusmalarini dinle (+10 Zeka, -25 Mutluluk)\n");
            printf("2. Odana git ve dinleme. (+8 Saglik, -15 Zeka )\n");
            while (1) {
                printf("Seciminizi yapin (1/2): ");
                if (scanf("%d", &secim) == 1 && (secim == 1 || secim == 2)) {
                    if (secim == 1) {
                        degerGuncelle(&oyuncu->zeka, 10, 0, 100);
                        degerGuncelle(&oyuncu->mutluluk, -25, 0, 100);
                        printf("Kavga hakkinda bilgi sahibi oldunuz ama moraliniz bozuldu.\n");
                    } else {
                        degerGuncelle(&oyuncu->zeka, -15, 0, 100);
                        degerGuncelle(&oyuncu->saglik, 8, 0, 100);
                        printf("Odaniza gittiniz ve kulakliklarinizi taktiniz.\n");
                    }
                    break;
                } else {
                    printf("Gecersiz secim yaptınız. Tekrar deneyin.\n");
                    while (getchar() != '\n');
                }
            }
            break;
        case 2:
        printf("\nEsila adinda bir kız sizinle arkadas olmak istedi. Ne yapacaksiniz ?\n");
        printf("1. Arkadas ol.\n");
        printf("2. Arkadas olma.\n");
        while (1) {
            printf("Seciminizi yapin (1/2): ");
            if (scanf("%d", &secim) == 1 && (secim == 1 || secim == 2)) {
                if (secim == 1) {
                    printf("Tebrikler artik Esila adinda arkadasiniz var!\n");
                } else {
                    printf("Yalniz kalmaya devam ettiniz.\n");
                }
                break;
            } else {
                printf("Gecersiz secim yaptınız. Tekrar deneyin.\n");
                while (getchar() != '\n');
            }
        }
        break;
        case 3:
        printf("\nFarkli muzik turleri dinlemek istediniz. Ne dinleyeceksiniz?\n");
        printf("1. Pop muzik.\n");
        printf("2. Klasik muzik.\n");
        while (1) {
            printf("Seciminizi yapin (1/2): ");
            if (scanf("%d", &secim) == 1 && (secim == 1 || secim == 2)) {
                if (secim == 1) {
                    printf("Artik tam bir pop muzik dj oldunuz!\n");
                } else {
                    printf("Kultur seviyesi daha farkli bir sey tabii ki!\n");
                }
                break;
            } else {
                printf("Gecersiz secim yaptınız. Tekrar deneyin.\n");
                while (getchar() != '\n');
            }
        }
        break;
        case 4:
        printf("\nYeni tarz bir oyun oynacaksiniz.Ne oynamak istersiniz?\n");
        printf("1. Hayat Secim Oyunu.\n");
        printf("2. Counter Strike.\n");
        while (1) {
            printf("Seciminizi yapin (1/2): ");
            if (scanf("%d", &secim) == 1 && (secim == 1 || secim == 2)) {
                if (secim == 1) {
                    printf("Secim oyununda sizden daha ustun biri yok!\n");
                } else {
                    printf("Birileri savas oyunlarindan zevk almaya basladi demek ki!\n");
                }
                break;
            } else {
                printf("Gecersiz secim yaptınız. Tekrar deneyin.\n");
                while (getchar() != '\n');
            }
        }
        break;
        case 5:
        printf("\nTebrikler bir kardesiniz oldu. Ne yapacaksiniz?\n");
        printf("1.Onu hastanede ziyaret et (+10 Zeka, -10 Mutluluk)\n");
        printf("2. Eve gelecek zaten, ziyaret etme. (+8 Mutluluk, -8 Zeka )\n");
        while (1) {
            printf("Seciminizi yapin (1/2): ");
            if (scanf("%d", &secim) == 1 && (secim == 1 || secim == 2)) {
                if (secim == 1) {
                    degerGuncelle(&oyuncu->zeka, 10, 0, 100);
                    degerGuncelle(&oyuncu->mutluluk, -10, 0, 100);
                    printf("Kardesiniz cok tatli! Fakat annenizi oyle gormek sizi uzdu.\n");
                } else {
                    degerGuncelle(&oyuncu->zeka, -8, 0, 100);
                    degerGuncelle(&oyuncu->mutluluk, 8, 0, 100);
                    printf("Aileniz ziyarete gelmediniz diye size kizdi.\n");
                }
                break;
            } else {
                printf("Gecersiz secim yaptınız. Tekrar deneyin.\n");
                while (getchar() != '\n');
            }
        }
        case 6:
            printf("\nOgretmeniniz size odev verdi. Ne yapacaksiniz?\n");
            printf("1.Odevi vaktinde yap.(+10 Zeka , -10 Mutluluk)\n");
            printf("2. Odevi sonra yapsam bir sey olmaz.(+8 Mutluluk , -8 Zeka)\n");
            while (1) {
                printf("Seciminizi yapin (1/2): ");
                if (scanf("%d", &secim) == 1 && (secim == 1 || secim == 2)) {
                    if (secim == 1) {
                        degerGuncelle(&oyuncu->zeka, 10, 0, 100);
                        degerGuncelle(&oyuncu->mutluluk, -10, 0, 100);
                        printf("Odevinizi vaktinde yaptiniz ogretmeniniz mutlu oldu.\n");
                    } else {
                        degerGuncelle(&oyuncu->zeka, -8, 0, 100);
                        degerGuncelle(&oyuncu->mutluluk, 8, 0, 100);
                        printf("Odevi sonra yapayim derken unuttunuz ve notunuz dustu.\n");
                    }
                    break;
                } else {
                    printf("Gecersiz secim yaptınız. Tekrar deneyin.\n");
                    while (getchar() != '\n');
                }
            }
        break;
        default:
            printf("Bu yilda bir olay yasanmadi.\n");
            break;
    }
}



int oyunBittiMi( struct Oyuncu *oyuncu) {
    return (oyuncu->saglik <= 0 || oyuncu->gorunus <= 0 || 
            oyuncu->zeka <= 0 || oyuncu->mutluluk <= 0 ) ;
}
int yasbitti( struct Oyuncu *oyuncu) {
    return (oyuncu->yas ==20) ;
}
int main() {
    struct Oyuncu oyuncu;
    srand(time(NULL));

    printf("Karakterinizin ismini girin: ");
    fgets(oyuncu.isim, sizeof(oyuncu.isim), stdin);
    oyuncu.isim[strcspn(oyuncu.isim, "\n")] = '\0';

    oyuncu.yas = 1;
    oyuncu.saglik = rand() % 51 + 50;
    oyuncu.mutluluk = rand() % 51 + 50;
    oyuncu.zeka = rand() % 51 + 50;
    oyuncu.gorunus = rand() % 51 + 50;
    oyuncu.para = 0;

    oyuncuBilgileriYazdir(&oyuncu);

    char devam;
    while (1) {
        printf("\nBir yil atlamak icin 'y', cikmak icin 'q' yazin: ");
        scanf(" %c", &devam);
        if (devam == 'y' || devam == 'Y') {
            oyuncu.yas++;
            printf("\n%d yasina girdiniz!\n", oyuncu.yas);
            oyuncuBilgileriYazdir(&oyuncu);

            if (oyuncu.yas >= 3 && oyuncu.yas <= 9) {
                // Olay durumunu sıfırla
                for (int i = 0; i < MAX_OLAY_1; i++) {
                    olayDurum1[i] = 0;
                }

                rastgeleOlay1(&oyuncu);
            } else if (oyuncu.yas >= 10) {
                // Olay durumunu sıfırla
                for (int i = 0; i < MAX_OLAY_2; i++) {
                    olayDurum2[i] = 0;
                }
                int olay = rand() % MAX_OLAY_2;
                rastgeleOlay2(&oyuncu);
            } else {
                printf("Bu yilda bir olay yasanmadi.\n");
            }

            if (oyunBittiMi(&oyuncu)) {
                printf("\nOyun Bitti! Hayatta kalamadiniz.\n");
                break;
            }
            if (yasbitti(&oyuncu)) {
                printf("\nOyun Bitti! 20 yasina geldiniz.\n");
                break;
            }
        } else if (devam == 'q' || devam == 'Q') {
            printf("\nOyunu sonlandirdiniz. Gorusmek uzere!\n");
            break;
        } else {
            printf("Gecersiz giris yaptiniz. Lütfen tekrar deneyin.\n");
        }
    }
    return 0;
}